
"�
�
LengthComparisonRouteTest$com.bellfamily.bastischool.ui.length<alignRestoreUndoRetryAndCompleteFiveAndTenWithSharedProgress2�������:ڨ�����}"�

logcatandroid�
�/home/runner/work/Basti-Learning-Adventure-Public/Basti-Learning-Adventure-Public/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-com.bellfamily.bastischool.ui.length.LengthComparisonRouteTest-alignRestoreUndoRetryAndCompleteFiveAndTenWithSharedProgress.txt"�

device-infoandroid�
�/home/runner/work/Basti-Learning-Adventure-Public/Basti-Learning-Adventure-Public/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/Basti-Learning-Adventure-Public/Basti-Learning-Adventure-Public/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/Basti-Learning-Adventure-Public/Basti-Learning-Adventure-Public/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
�
LengthComparisonOwnerTest$com.bellfamily.bastischool.ui.lengthAoffStaysLazyHiddenResultsStaySilentAndFreshOwnersRestoreExactWork2ڨ�����:ڨ����ƹ"�

logcatandroid�
�/home/runner/work/Basti-Learning-Adventure-Public/Basti-Learning-Adventure-Public/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-com.bellfamily.bastischool.ui.length.LengthComparisonOwnerTest-offStaysLazyHiddenResultsStaySilentAndFreshOwnersRestoreExactWork.txt"�

device-infoandroid�
�/home/runner/work/Basti-Learning-Adventure-Public/Basti-Learning-Adventure-Public/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/Basti-Learning-Adventure-Public/Basti-Learning-Adventure-Public/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/Basti-Learning-Adventure-Public/Basti-Learning-Adventure-Public/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
�
ConservationRouteTest*com.bellfamily.bastischool.ui.conservation;bothRangesMoveUndoRestoreRetryAndCompleteWithSharedProgress2ڨ�����:�����ٿ��
�
androidx.compose.ui.test.ComposeTimeoutException: Condition still not satisfied after 10000 ms
at androidx.compose.ui.test.AndroidComposeUiTestEnvironment$AndroidComposeUiTestImpl.waitUntil(ComposeUiTest.android.kt:441)
at androidx.compose.ui.test.junit4.AndroidComposeTestRule.waitUntil(AndroidComposeTestRule.android.kt:306)
at com.bellfamily.bastischool.ui.conservation.ConservationCaptureKt.captureConservationReview(ConservationCapture.kt:13)
at com.bellfamily.bastischool.ui.conservation.ConservationRouteTest.bothRangesMoveUndoRestoreRetryAndCompleteWithSharedProgress$lambda$15$lambda$14$capture(ConservationRouteTest.kt:37)
at com.bellfamily.bastischool.ui.conservation.ConservationRouteTest.bothRangesMoveUndoRestoreRetryAndCompleteWithSharedProgress$lambda$15(ConservationRouteTest.kt:83)
at com.bellfamily.bastischool.ui.conservation.ConservationRouteTest.$r8$lambda$-ZJH8FRwYTqKCBTEiIHBXH8YFkI(Unknown Source:0)
at com.bellfamily.bastischool.ui.conservation.ConservationRouteTest$$ExternalSyntheticLambda3.invoke(D8$$SyntheticClass:0)
at com.bellfamily.bastischool.ui.conservation.ConservationRouteTestKt.isolatedConservationStores(ConservationRouteTest.kt:23)
at com.bellfamily.bastischool.ui.conservation.ConservationRouteTest.bothRangesMoveUndoRestoreRetryAndCompleteWithSharedProgress(ConservationRouteTest.kt:28)
0androidx.compose.ui.test.ComposeTimeoutException�
androidx.compose.ui.test.ComposeTimeoutException: Condition still not satisfied after 10000 ms
at androidx.compose.ui.test.AndroidComposeUiTestEnvironment$AndroidComposeUiTestImpl.waitUntil(ComposeUiTest.android.kt:441)
at androidx.compose.ui.test.junit4.AndroidComposeTestRule.waitUntil(AndroidComposeTestRule.android.kt:306)
at com.bellfamily.bastischool.ui.conservation.ConservationCaptureKt.captureConservationReview(ConservationCapture.kt:13)
at com.bellfamily.bastischool.ui.conservation.ConservationRouteTest.bothRangesMoveUndoRestoreRetryAndCompleteWithSharedProgress$lambda$15$lambda$14$capture(ConservationRouteTest.kt:37)
at com.bellfamily.bastischool.ui.conservation.ConservationRouteTest.bothRangesMoveUndoRestoreRetryAndCompleteWithSharedProgress$lambda$15(ConservationRouteTest.kt:83)
at com.bellfamily.bastischool.ui.conservation.ConservationRouteTest.$r8$lambda$-ZJH8FRwYTqKCBTEiIHBXH8YFkI(Unknown Source:0)
at com.bellfamily.bastischool.ui.conservation.ConservationRouteTest$$ExternalSyntheticLambda3.invoke(D8$$SyntheticClass:0)
at com.bellfamily.bastischool.ui.conservation.ConservationRouteTestKt.isolatedConservationStores(ConservationRouteTest.kt:23)
at com.bellfamily.bastischool.ui.conservation.ConservationRouteTest.bothRangesMoveUndoRestoreRetryAndCompleteWithSharedProgress(ConservationRouteTest.kt:28)
"�

logcatandroid�
�/home/runner/work/Basti-Learning-Adventure-Public/Basti-Learning-Adventure-Public/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-com.bellfamily.bastischool.ui.conservation.ConservationRouteTest-bothRangesMoveUndoRestoreRetryAndCompleteWithSharedProgress.txt"�

device-infoandroid�
�/home/runner/work/Basti-Learning-Adventure-Public/Basti-Learning-Adventure-Public/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/Basti-Learning-Adventure-Public/Basti-Learning-Adventure-Public/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/Basti-Learning-Adventure-Public/Basti-Learning-Adventure-Public/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
�
ConservationOwnerTest*com.bellfamily.bastischool.ui.conservationAoffIsLazyLateLevelResultsAreRejectedAndFreshOwnersRestoreSilently2��������:������� "�

logcatandroid�
�/home/runner/work/Basti-Learning-Adventure-Public/Basti-Learning-Adventure-Public/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-com.bellfamily.bastischool.ui.conservation.ConservationOwnerTest-offIsLazyLateLevelResultsAreRejectedAndFreshOwnersRestoreSilently.txt"�

device-infoandroid�
�/home/runner/work/Basti-Learning-Adventure-Public/Basti-Learning-Adventure-Public/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/Basti-Learning-Adventure-Public/Basti-Learning-Adventure-Public/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/Basti-Learning-Adventure-Public/Basti-Learning-Adventure-Public/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
�
NumberStoriesRouteTest+com.bellfamily.bastischool.ui.numberstoriesKallFourChoicesRestoreEditsUndoWrongAndSolvedWorkAndCompleteFiveAndTenRounds2�������":�������^"�

logcatandroid�
�/home/runner/work/Basti-Learning-Adventure-Public/Basti-Learning-Adventure-Public/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-com.bellfamily.bastischool.ui.numberstories.NumberStoriesRouteTest-allFourChoicesRestoreEditsUndoWrongAndSolvedWorkAndCompleteFiveAndTenRounds.txt"�

device-infoandroid�
�/home/runner/work/Basti-Learning-Adventure-Public/Basti-Learning-Adventure-Public/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/Basti-Learning-Adventure-Public/Basti-Learning-Adventure-Public/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/Basti-Learning-Adventure-Public/Basti-Learning-Adventure-Public/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
�
NumberStoriesOwnerTest+com.bellfamily.bastischool.ui.numberstoriesAoffIsLazyLateLevelResultsAreRejectedAndFreshOwnersRestoreSilently2�������`:��������"�

logcatandroid�
�/home/runner/work/Basti-Learning-Adventure-Public/Basti-Learning-Adventure-Public/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-com.bellfamily.bastischool.ui.numberstories.NumberStoriesOwnerTest-offIsLazyLateLevelResultsAreRejectedAndFreshOwnersRestoreSilently.txt"�

device-infoandroid�
�/home/runner/work/Basti-Learning-Adventure-Public/Basti-Learning-Adventure-Public/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/Basti-Learning-Adventure-Public/Basti-Learning-Adventure-Public/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/Basti-Learning-Adventure-Public/Basti-Learning-Adventure-Public/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
�
QuantityChangeRouteTest,com.bellfamily.bastischool.ui.quantitychangeKallFourChoicesRestoreEditsUndoWrongAndSolvedWorkAndCompleteFiveAndTenRounds2��������:��������"�

logcatandroid�
�/home/runner/work/Basti-Learning-Adventure-Public/Basti-Learning-Adventure-Public/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-com.bellfamily.bastischool.ui.quantitychange.QuantityChangeRouteTest-allFourChoicesRestoreEditsUndoWrongAndSolvedWorkAndCompleteFiveAndTenRounds.txt"�

device-infoandroid�
�/home/runner/work/Basti-Learning-Adventure-Public/Basti-Learning-Adventure-Public/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/Basti-Learning-Adventure-Public/Basti-Learning-Adventure-Public/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/Basti-Learning-Adventure-Public/Basti-Learning-Adventure-Public/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
�
QuantityChangeOwnerTest,com.bellfamily.bastischool.ui.quantitychangeAoffIsLazyLateLevelResultsAreRejectedAndFreshOwnersRestoreSilently2��������:�������"�

logcatandroid�
�/home/runner/work/Basti-Learning-Adventure-Public/Basti-Learning-Adventure-Public/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-com.bellfamily.bastischool.ui.quantitychange.QuantityChangeOwnerTest-offIsLazyLateLevelResultsAreRejectedAndFreshOwnersRestoreSilently.txt"�

device-infoandroid�
�/home/runner/work/Basti-Learning-Adventure-Public/Basti-Learning-Adventure-Public/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/Basti-Learning-Adventure-Public/Basti-Learning-Adventure-Public/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/Basti-Learning-Adventure-Public/Basti-Learning-Adventure-Public/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
�
PatternRouteTest&com.bellfamily.bastischool.ui.patternsTallThreeRulesKeepTheirExamplesRestoreEditedAndCheckedWorkAndCompleteFiveAndTenRounds2��������:ѩ����"�

logcatandroid�
�/home/runner/work/Basti-Learning-Adventure-Public/Basti-Learning-Adventure-Public/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-com.bellfamily.bastischool.ui.patterns.PatternRouteTest-allThreeRulesKeepTheirExamplesRestoreEditedAndCheckedWorkAndCompleteFiveAndTenRounds.txt"�

device-infoandroid�
�/home/runner/work/Basti-Learning-Adventure-Public/Basti-Learning-Adventure-Public/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/Basti-Learning-Adventure-Public/Basti-Learning-Adventure-Public/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/Basti-Learning-Adventure-Public/Basti-Learning-Adventure-Public/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
�
PatternOwnerTest&com.bellfamily.bastischool.ui.patternsAoffIsLazyLateLevelResultsAreRejectedAndFreshOwnersRestoreSilently2ѩ�����:ѩ������"�

logcatandroid�
�/home/runner/work/Basti-Learning-Adventure-Public/Basti-Learning-Adventure-Public/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-com.bellfamily.bastischool.ui.patterns.PatternOwnerTest-offIsLazyLateLevelResultsAreRejectedAndFreshOwnersRestoreSilently.txt"�

device-infoandroid�
�/home/runner/work/Basti-Learning-Adventure-Public/Basti-Learning-Adventure-Public/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/Basti-Learning-Adventure-Public/Basti-Learning-Adventure-Public/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/Basti-Learning-Adventure-Public/Basti-Learning-Adventure-Public/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
�
MemoryPairsRouteTest$com.bellfamily.bastischool.ui.memoryHallSixBoardsRestoreTurnsTranslateUseSupportAndCompleteWithSharedBalloons2ѩ������:詖����"�

logcatandroid�
�/home/runner/work/Basti-Learning-Adventure-Public/Basti-Learning-Adventure-Public/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-com.bellfamily.bastischool.ui.memory.MemoryPairsRouteTest-allSixBoardsRestoreTurnsTranslateUseSupportAndCompleteWithSharedBalloons.txt"�

device-infoandroid�
�/home/runner/work/Basti-Learning-Adventure-Public/Basti-Learning-Adventure-Public/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/Basti-Learning-Adventure-Public/Basti-Learning-Adventure-Public/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/Basti-Learning-Adventure-Public/Basti-Learning-Adventure-Public/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
�
MemoryPairsOwnerTest$com.bellfamily.bastischool.ui.memoryToffIsLazyFreshOwnerRestoresSilentlyAndSwitchingWhileLoadingCannotPublishAnotherBoard2詖����*:詖�����"�

logcatandroid�
�/home/runner/work/Basti-Learning-Adventure-Public/Basti-Learning-Adventure-Public/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-com.bellfamily.bastischool.ui.memory.MemoryPairsOwnerTest-offIsLazyFreshOwnerRestoresSilentlyAndSwitchingWhileLoadingCannotPublishAnotherBoard.txt"�

device-infoandroid�
�/home/runner/work/Basti-Learning-Adventure-Public/Basti-Learning-Adventure-Public/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/Basti-Learning-Adventure-Public/Basti-Learning-Adventure-Public/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/Basti-Learning-Adventure-Public/Basti-Learning-Adventure-Public/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
�
MainActivityStartupTestcom.bellfamily.bastischool/homeSurvivesLaunchRecreationAndBackgroundReturn2詖�����:꩖����"�

logcatandroid�
�/home/runner/work/Basti-Learning-Adventure-Public/Basti-Learning-Adventure-Public/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-com.bellfamily.bastischool.MainActivityStartupTest-homeSurvivesLaunchRecreationAndBackgroundReturn.txt"�

device-infoandroid�
�/home/runner/work/Basti-Learning-Adventure-Public/Basti-Learning-Adventure-Public/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/Basti-Learning-Adventure-Public/Basti-Learning-Adventure-Public/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/Basti-Learning-Adventure-Public/Basti-Learning-Adventure-Public/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
�
SweepRepairsRouteTestcom.bellfamily.bastischool9matchingOptionsRecreationReturnsToBothOriginalBrowsePages2꩖�����:쩖�����"�

logcatandroid�
�/home/runner/work/Basti-Learning-Adventure-Public/Basti-Learning-Adventure-Public/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-com.bellfamily.bastischool.SweepRepairsRouteTest-matchingOptionsRecreationReturnsToBothOriginalBrowsePages.txt"�

device-infoandroid�
�/home/runner/work/Basti-Learning-Adventure-Public/Basti-Learning-Adventure-Public/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/Basti-Learning-Adventure-Public/Basti-Learning-Adventure-Public/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/Basti-Learning-Adventure-Public/Basti-Learning-Adventure-Public/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
�
SweepRepairsRouteTestcom.bellfamily.bastischool>thumbnailAndStepPicturesDecodeAtBoundedSizeAndMissingArtIsSafe2쩖�����:�������J"�

logcatandroid�
�/home/runner/work/Basti-Learning-Adventure-Public/Basti-Learning-Adventure-Public/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-com.bellfamily.bastischool.SweepRepairsRouteTest-thumbnailAndStepPicturesDecodeAtBoundedSizeAndMissingArtIsSafe.txt"�

device-infoandroid�
�/home/runner/work/Basti-Learning-Adventure-Public/Basti-Learning-Adventure-Public/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/Basti-Learning-Adventure-Public/Basti-Learning-Adventure-Public/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/Basti-Learning-Adventure-Public/Basti-Learning-Adventure-Public/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
�
SweepRepairsRouteTestcom.bellfamily.bastischool2activityThumbnailsAreVisibleThroughRealBrowsePages2�������X:節���\"�

logcatandroid�
�/home/runner/work/Basti-Learning-Adventure-Public/Basti-Learning-Adventure-Public/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-com.bellfamily.bastischool.SweepRepairsRouteTest-activityThumbnailsAreVisibleThroughRealBrowsePages.txt"�

device-infoandroid�
�/home/runner/work/Basti-Learning-Adventure-Public/Basti-Learning-Adventure-Public/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/Basti-Learning-Adventure-Public/Basti-Learning-Adventure-Public/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/Basti-Learning-Adventure-Public/Basti-Learning-Adventure-Public/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
�
VerbsRouteTest#com.bellfamily.bastischool.ui.verbsHquizLessonSettingsRecreationAndCompletionPreserveExactQuestionAndChoices2節���j:�����"�

logcatandroid�
�/home/runner/work/Basti-Learning-Adventure-Public/Basti-Learning-Adventure-Public/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-com.bellfamily.bastischool.ui.verbs.VerbsRouteTest-quizLessonSettingsRecreationAndCompletionPreserveExactQuestionAndChoices.txt"�

device-infoandroid�
�/home/runner/work/Basti-Learning-Adventure-Public/Basti-Learning-Adventure-Public/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/Basti-Learning-Adventure-Public/Basti-Learning-Adventure-Public/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/Basti-Learning-Adventure-Public/Basti-Learning-Adventure-Public/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
�
NumberBondsRouteTest#com.bellfamily.bastischool.ui.bondsCbothLevelsKeepFixedEggsRestoreAddedEggsAndCompleteWithSharedRewards2�����:��������"�

logcatandroid�
�/home/runner/work/Basti-Learning-Adventure-Public/Basti-Learning-Adventure-Public/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-com.bellfamily.bastischool.ui.bonds.NumberBondsRouteTest-bothLevelsKeepFixedEggsRestoreAddedEggsAndCompleteWithSharedRewards.txt"�

device-infoandroid�
�/home/runner/work/Basti-Learning-Adventure-Public/Basti-Learning-Adventure-Public/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/Basti-Learning-Adventure-Public/Basti-Learning-Adventure-Public/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/Basti-Learning-Adventure-Public/Basti-Learning-Adventure-Public/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
�
WashHandsScreenTest'com.bellfamily.bastischool.ui.washhandsGlistenKeyboardBuildCheckUndoHintAndCompletionRemainReachable[ENGLISH-1]2��������:��������"�

logcatandroid�
�/home/runner/work/Basti-Learning-Adventure-Public/Basti-Learning-Adventure-Public/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-com.bellfamily.bastischool.ui.washhands.WashHandsScreenTest-listenKeyboardBuildCheckUndoHintAndCompletionRemainReachable[ENGLISH-1].txt"�

device-infoandroid�
�/home/runner/work/Basti-Learning-Adventure-Public/Basti-Learning-Adventure-Public/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/Basti-Learning-Adventure-Public/Basti-Learning-Adventure-Public/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/Basti-Learning-Adventure-Public/Basti-Learning-Adventure-Public/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
�
WashHandsScreenTest'com.bellfamily.bastischool.ui.washhandsFlistenKeyboardBuildCheckUndoHintAndCompletionRemainReachable[GERMAN-1]2��������:�����ꗢ"�

logcatandroid�
�/home/runner/work/Basti-Learning-Adventure-Public/Basti-Learning-Adventure-Public/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-com.bellfamily.bastischool.ui.washhands.WashHandsScreenTest-listenKeyboardBuildCheckUndoHintAndCompletionRemainReachable[GERMAN-1].txt"�

device-infoandroid�
�/home/runner/work/Basti-Learning-Adventure-Public/Basti-Learning-Adventure-Public/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/Basti-Learning-Adventure-Public/Basti-Learning-Adventure-Public/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/Basti-Learning-Adventure-Public/Basti-Learning-Adventure-Public/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
�
WashHandsScreenTest'com.bellfamily.bastischool.ui.washhandsFlistenKeyboardBuildCheckUndoHintAndCompletionRemainReachable[GERMAN-0]2������:�����ۤ�"�

logcatandroid�
�/home/runner/work/Basti-Learning-Adventure-Public/Basti-Learning-Adventure-Public/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-com.bellfamily.bastischool.ui.washhands.WashHandsScreenTest-listenKeyboardBuildCheckUndoHintAndCompletionRemainReachable[GERMAN-0].txt"�

device-infoandroid�
�/home/runner/work/Basti-Learning-Adventure-Public/Basti-Learning-Adventure-Public/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/Basti-Learning-Adventure-Public/Basti-Learning-Adventure-Public/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/Basti-Learning-Adventure-Public/Basti-Learning-Adventure-Public/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
�
WashHandsScreenTest'com.bellfamily.bastischool.ui.washhandsFlistenKeyboardBuildCheckUndoHintAndCompletionRemainReachable[GERMAN-8]2�������:�������"�

logcatandroid�
�/home/runner/work/Basti-Learning-Adventure-Public/Basti-Learning-Adventure-Public/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-com.bellfamily.bastischool.ui.washhands.WashHandsScreenTest-listenKeyboardBuildCheckUndoHintAndCompletionRemainReachable[GERMAN-8].txt"�

device-infoandroid�
�/home/runner/work/Basti-Learning-Adventure-Public/Basti-Learning-Adventure-Public/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/Basti-Learning-Adventure-Public/Basti-Learning-Adventure-Public/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/Basti-Learning-Adventure-Public/Basti-Learning-Adventure-Public/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
�
WashHandsLifecycleTest'com.bellfamily.bastischool.ui.washhandsJeditsWrongWorkCompletionAndNewRoundSurviveLifecycleAndRepeatedDisposal[en]2������3:��������"�

logcatandroid�
�/home/runner/work/Basti-Learning-Adventure-Public/Basti-Learning-Adventure-Public/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-com.bellfamily.bastischool.ui.washhands.WashHandsLifecycleTest-editsWrongWorkCompletionAndNewRoundSurviveLifecycleAndRepeatedDisposal[en].txt"�

device-infoandroid�
�/home/runner/work/Basti-Learning-Adventure-Public/Basti-Learning-Adventure-Public/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/Basti-Learning-Adventure-Public/Basti-Learning-Adventure-Public/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/Basti-Learning-Adventure-Public/Basti-Learning-Adventure-Public/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
�
WashHandsLifecycleTest'com.bellfamily.bastischool.ui.washhandsJeditsWrongWorkCompletionAndNewRoundSurviveLifecycleAndRepeatedDisposal[de]2��������:�����π�"�

logcatandroid�
�/home/runner/work/Basti-Learning-Adventure-Public/Basti-Learning-Adventure-Public/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-com.bellfamily.bastischool.ui.washhands.WashHandsLifecycleTest-editsWrongWorkCompletionAndNewRoundSurviveLifecycleAndRepeatedDisposal[de].txt"�

device-infoandroid�
�/home/runner/work/Basti-Learning-Adventure-Public/Basti-Learning-Adventure-Public/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/Basti-Learning-Adventure-Public/Basti-Learning-Adventure-Public/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/Basti-Learning-Adventure-Public/Basti-Learning-Adventure-Public/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
�
VocabularyArtworkLoaderTest(com.bellfamily.bastischool.ui.vocabulary4allImagesDecodeOnceAtBoundedSizeAndReuseTheSameCache2��������:��������"�

logcatandroid�
�/home/runner/work/Basti-Learning-Adventure-Public/Basti-Learning-Adventure-Public/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-com.bellfamily.bastischool.ui.vocabulary.VocabularyArtworkLoaderTest-allImagesDecodeOnceAtBoundedSizeAndReuseTheSameCache.txt"�

device-infoandroid�
�/home/runner/work/Basti-Learning-Adventure-Public/Basti-Learning-Adventure-Public/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/Basti-Learning-Adventure-Public/Basti-Learning-Adventure-Public/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/Basti-Learning-Adventure-Public/Basti-Learning-Adventure-Public/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
�
VocabularyArtworkLoaderTest(com.bellfamily.bastischool.ui.vocabularyOmissingAndCorruptImagesAreIsolatedAndCachedWithoutReplacingThemWithOtherAnimals2��������:��������"�

logcatandroid�
�/home/runner/work/Basti-Learning-Adventure-Public/Basti-Learning-Adventure-Public/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-com.bellfamily.bastischool.ui.vocabulary.VocabularyArtworkLoaderTest-missingAndCorruptImagesAreIsolatedAndCachedWithoutReplacingThemWithOtherAnimals.txt"�

device-infoandroid�
�/home/runner/work/Basti-Learning-Adventure-Public/Basti-Learning-Adventure-Public/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/Basti-Learning-Adventure-Public/Basti-Learning-Adventure-Public/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/Basti-Learning-Adventure-Public/Basti-Learning-Adventure-Public/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
�
FoodVocabularyRouteTest(com.bellfamily.bastischool.ui.vocabularyAfoodExploreFindNameLanguageAndCategorySwitchPreserveSavedPractice2��������:�������l"�

logcatandroid�
�/home/runner/work/Basti-Learning-Adventure-Public/Basti-Learning-Adventure-Public/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-com.bellfamily.bastischool.ui.vocabulary.FoodVocabularyRouteTest-foodExploreFindNameLanguageAndCategorySwitchPreserveSavedPractice.txt"�

device-infoandroid�
�/home/runner/work/Basti-Learning-Adventure-Public/Basti-Learning-Adventure-Public/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/Basti-Learning-Adventure-Public/Basti-Learning-Adventure-Public/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/Basti-Learning-Adventure-Public/Basti-Learning-Adventure-Public/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
�
PrepositionsArtworkScreenTest*com.bellfamily.bastischool.ui.prepositionsKartworkDescriptionsChoicesActionsAndFailureStayUsableAtLargeFont[ENGLISH-1]2�������n:��������"�

logcatandroid�
�/home/runner/work/Basti-Learning-Adventure-Public/Basti-Learning-Adventure-Public/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-com.bellfamily.bastischool.ui.prepositions.PrepositionsArtworkScreenTest-artworkDescriptionsChoicesActionsAndFailureStayUsableAtLargeFont[ENGLISH-1].txt"�

device-infoandroid�
�/home/runner/work/Basti-Learning-Adventure-Public/Basti-Learning-Adventure-Public/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/Basti-Learning-Adventure-Public/Basti-Learning-Adventure-Public/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/Basti-Learning-Adventure-Public/Basti-Learning-Adventure-Public/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
�
PrepositionsArtworkScreenTest*com.bellfamily.bastischool.ui.prepositionsJartworkDescriptionsChoicesActionsAndFailureStayUsableAtLargeFont[GERMAN-1]2�������:������Ͳ"�

logcatandroid�
�/home/runner/work/Basti-Learning-Adventure-Public/Basti-Learning-Adventure-Public/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-com.bellfamily.bastischool.ui.prepositions.PrepositionsArtworkScreenTest-artworkDescriptionsChoicesActionsAndFailureStayUsableAtLargeFont[GERMAN-1].txt"�

device-infoandroid�
�/home/runner/work/Basti-Learning-Adventure-Public/Basti-Learning-Adventure-Public/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/Basti-Learning-Adventure-Public/Basti-Learning-Adventure-Public/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/Basti-Learning-Adventure-Public/Basti-Learning-Adventure-Public/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
�
PrepositionsArtworkScreenTest*com.bellfamily.bastischool.ui.prepositionsJartworkDescriptionsChoicesActionsAndFailureStayUsableAtLargeFont[GERMAN-0]2������ǳ:�������z"�

logcatandroid�
�/home/runner/work/Basti-Learning-Adventure-Public/Basti-Learning-Adventure-Public/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-com.bellfamily.bastischool.ui.prepositions.PrepositionsArtworkScreenTest-artworkDescriptionsChoicesActionsAndFailureStayUsableAtLargeFont[GERMAN-0].txt"�

device-infoandroid�
�/home/runner/work/Basti-Learning-Adventure-Public/Basti-Learning-Adventure-Public/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/Basti-Learning-Adventure-Public/Basti-Learning-Adventure-Public/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/Basti-Learning-Adventure-Public/Basti-Learning-Adventure-Public/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
�
PrepositionsArtworkScreenTest*com.bellfamily.bastischool.ui.prepositionsJartworkDescriptionsChoicesActionsAndFailureStayUsableAtLargeFont[GERMAN-8]2��������:Ū������"�

logcatandroid�
�/home/runner/work/Basti-Learning-Adventure-Public/Basti-Learning-Adventure-Public/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-com.bellfamily.bastischool.ui.prepositions.PrepositionsArtworkScreenTest-artworkDescriptionsChoicesActionsAndFailureStayUsableAtLargeFont[GERMAN-8].txt"�

device-infoandroid�
�/home/runner/work/Basti-Learning-Adventure-Public/Basti-Learning-Adventure-Public/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/Basti-Learning-Adventure-Public/Basti-Learning-Adventure-Public/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/Basti-Learning-Adventure-Public/Basti-Learning-Adventure-Public/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
�
"PrepositionsGuidedListenScreenTest*com.bellfamily.bastischool.ui.prepositions:germanGuidedOutlineAdvancesAndClearsAtLargeTextNarrowWidth2Ū������:ƪ������"�

logcatandroid�
�/home/runner/work/Basti-Learning-Adventure-Public/Basti-Learning-Adventure-Public/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-com.bellfamily.bastischool.ui.prepositions.PrepositionsGuidedListenScreenTest-germanGuidedOutlineAdvancesAndClearsAtLargeTextNarrowWidth.txt"�

device-infoandroid�
�/home/runner/work/Basti-Learning-Adventure-Public/Basti-Learning-Adventure-Public/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/Basti-Learning-Adventure-Public/Basti-Learning-Adventure-Public/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/Basti-Learning-Adventure-Public/Basti-Learning-Adventure-Public/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
�
"PrepositionsGuidedListenScreenTest*com.bellfamily.bastischool.ui.prepositions;englishGuidedOutlineAdvancesAndClearsAtLargeTextNarrowWidth2ƪ������:Ȫ�����"�

logcatandroid�
�/home/runner/work/Basti-Learning-Adventure-Public/Basti-Learning-Adventure-Public/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-com.bellfamily.bastischool.ui.prepositions.PrepositionsGuidedListenScreenTest-englishGuidedOutlineAdvancesAndClearsAtLargeTextNarrowWidth.txt"�

device-infoandroid�
�/home/runner/work/Basti-Learning-Adventure-Public/Basti-Learning-Adventure-Public/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/Basti-Learning-Adventure-Public/Basti-Learning-Adventure-Public/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/Basti-Learning-Adventure-Public/Basti-Learning-Adventure-Public/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�	
�
"PrepositionsGuidedListenScreenTest*com.bellfamily.bastischool.ui.prepositionsOindividualListenIsSeparateFromImmediateKeyboardAnswerAndNavigationClearsOutline2Ȫ����':ɪ������"�

logcatandroid�
�/home/runner/work/Basti-Learning-Adventure-Public/Basti-Learning-Adventure-Public/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-com.bellfamily.bastischool.ui.prepositions.PrepositionsGuidedListenScreenTest-individualListenIsSeparateFromImmediateKeyboardAnswerAndNavigationClearsOutline.txt"�

device-infoandroid�
�/home/runner/work/Basti-Learning-Adventure-Public/Basti-Learning-Adventure-Public/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/Basti-Learning-Adventure-Public/Basti-Learning-Adventure-Public/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/Basti-Learning-Adventure-Public/Basti-Learning-Adventure-Public/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo*�
c
test-results.logOcom.google.testing.platform.runtime.android.driver.AndroidInstrumentationDriver�
�/home/runner/work/Basti-Learning-Adventure-Public/Basti-Learning-Adventure-Public/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/testlog/test-results.log 2
text/plain